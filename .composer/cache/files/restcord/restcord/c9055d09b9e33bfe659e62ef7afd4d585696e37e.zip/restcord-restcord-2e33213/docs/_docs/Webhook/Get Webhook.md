---
title: Get Webhook
category: Webhook
order: 4
---

# `getWebhook`

```php
$client->webhook->getWebhook($parameters);
```

## Description



## Parameters


Name | Type | Required | Default
--- | --- | --- | ---
webhook.id | snowflake | true | *null*

## Response

Returns the new webhook object for the given id.

Can Return:

* webhook
