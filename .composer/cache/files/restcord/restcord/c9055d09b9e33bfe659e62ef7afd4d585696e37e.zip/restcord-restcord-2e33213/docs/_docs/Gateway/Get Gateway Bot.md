---
title: Get Gateway Bot
category: Gateway
order: 2
---

# `getGatewayBot`

```php
$client->gateway->getGatewayBot($parameters);
```

## Description

This endpoint requires authentication using a valid bot token.

## Parameters

No Parameters

## Response

Possibly No Response

